"""CFlow Platform package (Phase 1 wrapper for extraction)."""

__version__ = "0.1.0"

__all__ = [
    "public_api",
]


