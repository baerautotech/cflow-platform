# Changelog

All notable changes to this project will be documented in this file.

## 0.1.0 - Initial Phase 1 wrapper
- Public API proxy, SDK client, CLI entry points
- Env verifier wrapper and hooks installer wrapper
- Functional hook shims delegating to repo hooks
